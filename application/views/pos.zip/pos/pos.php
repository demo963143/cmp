<link rel="stylesheet" href="<?= base_url(); ?>assets/css/vendor/select2.min.css" />
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/vendor/select2-bootstrap.min.css" />


<style>
    .iconsminds-zouhir:before {
        content: '\e227';
    }

    .register-img {
        fill: #ed7117;
    }

    .selectedGat {
        background-color: #17a2b8;
        border: 1px solid #17a2b8;
    }

    .selectedProd {
        background-color: #17a2b8;
        border: 1px solid #17a2b8;
        color: #ffffff;
    }

    .selectedbtm {
        background-color: #17a2b8;
        border: 1px solid #17a2b8;
        color: #ffffff;
    }

    .selectedbtm2 {
        background-color: #17a2b8;
        border: 1px solid #17a2b8;
        color: #ffffff;
    }

    .rtl .input-group>.input-group-prepend>.btn {
        border-radius: 0px
    }

    .rtl .input-group>.input-group-append>.btn {
        border-radius: 0px
    }

    .scrollbar {
        height: 240px;
        overflow-y: scroll;
        overflow-x: hidden;
        margin-bottom: 5px;
    }

    #style-1::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
        border-radius: 1px;
        background-color: #ececec;
    }

    #style-1::-webkit-scrollbar {
        width: 10px;
        background-color: #ececec;
    }

    #style-1::-webkit-scrollbar-thumb {
        border-radius: 10px;
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, .3);
        background-color: #138496;
    }

    #printSection {
        color: #000;
        margin: 0 auto;
          
    }
    
        #printSection img {
       width:15.5rem !important;
         
    }

    #ticket .modal-dialog {
        width: 100%;
    }


    #modal-body {
        max-height: calc(100vh - 200px);
        overflow-y: auto;
    }

    /*print styling*/

    @media print {
        .modal-dialog {
            width: 100% !important;
            ;
        }

        .modal {
            visibility: visible;
            /**Remove scrollbar for printing.**/
            overflow: visible !important;
        }

        .modal-dialog {
            visibility: visible !important;
            /**Remove scrollbar for printing.**/
            overflow: visible !important;
            height: auto !important;
            width: auto !important;
        }

        body * {
            visibility: hidden;
        }

        .container-fluid {
            display: none;
        }

        #printSection,
        #printSection * {
            visibility: visible;
           
        }

        #printSectionInvoice,
        #printSectionInvoice * {
            visibility: visible;
          
        }

        #printSection {
            text-transform: uppercase;
            font-size: 14px;
            font-weight:600;
            left: 0;
            top: 0;
            padding: 0;
            margin: 0;
        }

        #printSection h4 {
            font-size: 14px;
            font-weight:600;
        }

        #printSection {
            font-size: 14px;
            font-weight:600;
        }

        #printSection tr td {
            margin: 0;
            padding: 0;
            
             
        }

        #printSection .bg-success,
        #printSection .bg-danger {
            visibility: hidden;
        }

        .table {
            color: #000000;
           
        }

        @page {
            margin: 0;
        }

        .hiddenpr {
            display: none !important;
        }

        html,
        body {
            zoom: 95%;
            overflow: hidden !important;
        }

    }
</style>




<!-----------------Main Content------------------------->

<div class="row">
    <div class="col-xl-6 col-lg-12 mb-0">
        <div class="card">
            <div class="card-body p-2">
                <div class="w-100 mb-2">
                    <button type="button" class="btn btn-primary btn-lg mb-1 w-20 text-center default categories selectedGat" id=""><?= display('all') ?></button>
                    <?php
                    foreach ($categories as $category) {
                    ?>
                        <button type="button" class="btn btn-primary btn-lg mb-1 text-center default categories" id="<?= $category->id; ?>"><?= $category->name; ?></button>
                    <?PHP
                    }
                    ?>

                </div>
                <div class="row px-4 py-1 productsearch">
                <input type="text" id="productsearch" class="form-control col-8" placeholder=" <?= display('find_an_product') ?> " style="font-size: 15px;">
                <button type="button" class="btn btn-primary  text-center default mr-2 ml-2" onclick="productSearch()">
                    <?= display('search') ?> <i class="simple-icon-magnifier"></i>
                </button>
                <span id="errorproduct_search" class="text-danger"></span>
             </div>
                <div class="scroll dashboard-list-with-thumbs ps ps--active-y" id="productList" style="display:block;height:500px">

                    <?PHP
                    if ($products) {
                        foreach ($products as $product) :
                    ?>
                            <a href="javascript:void(0)" class="btn btn-light default mb-1 mr-1 addPct" style="width: 18.8%!important; border-top:4px solid #138496; height:100px" id="<?= $product->num; ?>" onclick="add_prodpos('<?= $product->id; ?>')">
                                <div class="card-body text-center p-1">
                                    <?PHP
                                    $type = substr($product->icon, strrpos($product->icon, '.') + 0);
                                    if ($type == '.svg') {
                                    ?>
                                        <img class="mt-1 mb-1" src="<?= base_url() . '/files/svg/' . $product->icon; ?>" width="45%">
                                    <?PHP
                                    } else {
                                    ?>
                                        <i class="<?= $product->icon; ?>" style="font-size: 30px;"></i>
                                    <?PHP
                                    }
                                    ?>
                                    <p class="card-text mb-2"><?= $product->name; ?></p>

                                    <input type="hidden" id="idname-<?= $product->id; ?>" name="name" value="<?= $product->name; ?>" />
                                    <input type="hidden" id="category" name="category" value="<?= $product->category_id; ?>" />
                                    <input type="hidden" id="price-<?= $product->id; ?>" name="category" value="<?= $product->category_id; ?>" />

                                </div>


                            </a>
                        <?PHP
                        endforeach;
                    } else {
                        ?>
                        <div id="" style="overflow: hidden; width: 95%; height: 220px; margin: 20px">
                            <div class="messageVide"><?= display('empty') ?> <span></span></div>
                        </div>
                    <?PHP
                    }
                    ?>


                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-lg-12 mb-0">

        <div class="card">

            <form>
                <div class="card-body p-2">

                    <div class=" ps ps--active-y">
                        <button type="button" class="btn btn-light  btn-lg mb-1 w-100 text-center default selectype1" style="border-top:4px solid #138496;" id="laundry"><?= display('laundry') ?></button>
                        <button type="button" class="btn btn-light  btn-lg mb-1 w-100 text-center default selectype1" style="border-top:4px solid #138496;" id="lroning">Ironing<?//= display('ironing') ?> </button>
                        <button type="button" class="btn btn-light  btn-lg mb-1 w-100 text-center default selectype1" style="border-top:4px solid #138496;" id="laundrylroning"><?= display('laundrylroning') ?> </button>
                        <button type="button" class="btn btn-light  btn-lg mb-1 w-100 text-center default selectype1" style="border-top:4px solid #138496;" id="dry"> <?= display('dry_wash') ?> </button>
                        <button type="button" class="btn btn-light  btn-lg mb-1 w-100 text-center default selectype1" style="border-top:4px solid #138496;" id="other"> <?= display('other_services') ?> </button>

                        <hr>
                        <button type="button" class="btn btn-light  btn-lg mb-1 w-100 text-center default selectype2" style="border-top:4px solid #138496;" id="normal"> <?= display('normal') ?> </button>
                        <button type="button" class="btn btn-light  btn-lg mb-1 w-100 text-center default selectype2" style="border-top:4px solid #138496;" id="fast">Express</button>
                        <div class="w-100">
                            <input type="number" value="1" min="1" max="100" step="1" id="" name="qtecart" />
                        </div>
                        <hr>
                        <select id="color" name="color" class="form-control mb-4" data-width="100%" data-height="20%" required>
                            <option value="<?=display('white')?>" style="background-color: #ffffff;"><?= display('color') ?></option>

                            <?PHP
                            foreach ($colors as $color) {
                            ?>
                                <option value="<?= $color->name ?>" style="background-color:<?= $color->color ?>;"> <?= $color->name ?></option>
                            <?PHP
                            }
                            ?>
                        </select>

                        <button type="button" class="btn btn-primary  btn-lg mb-1 w-100 text-center default" onclick="add_posale()"> <?= display('add') ?> </button>

                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="col-xl-4 col-lg-12 mb-0">

        <div class="card">
            <div class="row px-4 py-1">
                <input type="text" id="salesearch" class="form-control col-8" placeholder=" <?= display('find_an_invoice') ?> " style="font-size: 15px;">
                <button type="button" class="btn btn-primary  text-center default mr-2 ml-2" onclick="SaleSearch()">
                    <?= display('search') ?> <i class="simple-icon-magnifier"></i>
                </button>
                <span id="errorsale_searsh" class="text-danger"></span>
            </div>
            <div class="card-body px-2 py-0">

                <div class="row p-3">

                    <select id="customerSelect" name="" class="form-control select2-single" data-width="50%" data-height="20%">
                        <option value="0"><?= display('default_client') ?></option>
                        <?php
                        foreach ($clients as $client) {
                           
                        ?>
                            <option value="<?= $client->id; ?>"><?= $client->lastname . ' ' . $client->firstname . ' ' . $client->phone; ?></option>
                        <?PHP
                        }
                        ?>
                    </select>
                    <button type="button" class="btn btn-primary  text-center default mr-2 ml-2" data-toggle="modal" data-target="#clientModal">
                        <?= display('add_a_new_customer') ?> <i class="simple-icon-user-follow"></i>
                    </button>
                    <div class="input-group col-lg-8 mt-1 pl-0">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">@</div>
                                    </div>
                             <input type="text" class="form-control" id="phoneClient" placeholder="<?= display('phone') ?>">
                        </div>
                        <div class="input-group col-lg-8 mt-1 pl-0">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Pickup Date</div>
                                    </div>
                             <input type="date" class="form-control" id="pickup_date" name="pickup_date" placeholder="Pickup Date">
                        </div>
                        <div class="input-group col-lg-8 mt-1 pl-0">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Delivery Date</div>
                                    </div>
                             <input type="date" class="form-control" id="delivery_date" name="delivery_date" placeholder="Delivery Date">
                        </div>
                        
                       
                
                </div>

                <div class="dashboard-list-with-thumbs ps ps--active-y" style="height: 450px;">



                    <div class="col-md-13">
                        <div class="info mt-4">
                            <div class="row mt-2 pb-1" style="border-bottom:1px solid #138496; color:#0b414a">
                                <div class="col-md-3 product-name">
                                    <div><?= display('product') ?> </div>
                                </div>
                                <div class="col-md-3 product-name">
                                    <div> <?= display('service') ?></div>
                                </div>

                                <div class="col-md-2 price text-center">
                                    <span><?= display('quantity') ?></span>
                                </div>
                                <div class="col-md-2 price text-center">
                                    <span><?= display('price') ?></span>
                                </div>
                                <div class="col-md-1  text-center">
                                    <span></span>
                                </div>
                            </div>
                            <div class="scrollbar" id="style-1">
                                <div class="cartview" id="cartview">


                                    <?PHP
                                    if ($posales) {
                                        foreach ($posales as $posale) {
                                            $product = $this->product->get_by_id($posale->product_id);
                                            $storeid = $this->session->userdata('store_id');
                                            $services = $this->posale->get_all(array('parent' => $posale->id, 'register' => $this->register, 'store_id' => $this->store_id));
                                            if ($posale->price > 0) {
                                                $posale_price = $posale->price . '' . settings()->currency;
                                            } else {
                                                $posale_price = '';
                                            }


                                            $row = '<div class="row mt-2 pb-1" style="border-bottom:1px dotted #138496">
				 <div class="col-md-3">
							 <div>' . $product->name . ' : <span class="value">' . $product->category_name . '</span></div>
                             <div> ' . display('color') . ': <span class="value">' . $posale->color . '</span></div>
				 </div>
				 <div class="col-md-3">
							 <div>' . display($posale->type_one) . ': <span class="value">' . display($posale->type_second) . '</span><BR> ' . $posale_price . ' </div>
				 </div>
				 
				 <div class="col-md-2 text-center">
                     <span class="font-weight-bold">' . $posale->quantity . '</span>
                     

                 </div><div class="col-md-2 text-center">';
                                            if ($posale->total > 0) {
                                                $row .= '<span class="font-weight-bold">' . number_format((float)$posale->total, settings()->decimals, '.', '') . '</span>';
                                            }

                                            $row .= '</div><div class="col-md-1 text-center">
                 <span class="font-weight-bold"><a href="javascript:void(0)" onclick="delete_posale(' . "'" . $posale->id . "'" . ')"><div class="glyph-icon simple-icon-trash text-danger"></div></a></span>
                 </div><div class="col-md-12">';
                                            foreach ($services as $service) {
                                                $row .= '<a href="javascript:void(0)" onclick="delete_posale(' . $service->id . ')"><span class="badge badge-pill badge-success mb-1"><i class="glyph-icon simple-icon-close"></i> ' . $service->product_name . ' (' . $service->total . ') ' . settings()->currency . '</span></a>';
                                            }
                                            $row .= '</div><div class="col-md-12"><a href="javascript:void(0)" onclick="edit_posale(' . "'" . $posale->id . "','increment'" . ')"><span class="btn btn-light default mr-1">+</span></a><a href="javascript:void(0)" onclick="edit_posale(' . "'" . $posale->id . "','decrement'" . ')"><span class="btn btn-light default ">-</span></a>
                 <a href="#servicemodal" class="green" id="custId" data-toggle="modal" data-id="' . $posale->id . '"><span class="btn btn-success default">إضافة خدمات</span></a>
                 </div>
			 </div>';

                                            echo  $row;
                                        }
                                    } else {
                                        echo '<br><span class="m-5 text-center col-md-12">' . display('empty') . '</span>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="table-responsive col-sm-12 totalTab" style="background-color: #f8f8f8; border:1px solid #f1efef">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td class="active" width="40%" style="padding:3px"> <?= display('subtotal'); ?></td>
                                            <td class="whiteBg" width="60%" style="padding:3px"><span id="Subtot">0.00</span> <?= settings()->currency; ?> <span class="float-right"><b id="ItemsNum"><span>0</span> <?= display('number_of_services'); ?></b></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="active" style="padding:3px"><?= display('tax'); ?></td>
                                            <td class="whiteBg" style="padding:3px"><input type="text" value="<?= settings()->tax; ?>" onchange="total_change()" id="taxValue" class="total-input TAX form-control" placeholder="" maxlength="5">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="active" style="padding:3px"><?= display('discounts'); ?></td>
                                            <td class="whiteBg" style="padding:3px"><input type="text" value="<?= settings()->discount; ?>" onchange="total_change()" id="RemiseValue" class="total-input Remise form-control" placeholder="" maxlength="5">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="active" style="padding:3px"><?= display('total'); ?></td>
                                            <td class="whiteBg light-blue text-bold" style="padding:3px"><span id="total">0.00</span> <?= settings()->currency; ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>



                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-lg-12 mb-4">
        <div class="card">
            <div class="card-body p-2">
                <div class="btn btn-success default w-100">
                    <h3><i class="glyph-icon iconsminds-money-bag"></i> <?= display('daily_sales'); ?> :
                        <span id="total_sales">
                            <?= number_format((float)($sum_sale_day), settings()->decimals, '.', '') ?>
                        </span> <?= settings()->currency; ?>
                    </h3>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-lg-12 mb-4">
        <div class="card">
            <div class="card-body p-2">
                <div class="btn btn-success default w-100">
                    <h3><i class="glyph-icon simple-icon-calculator"></i> <?= display('number_of_daily_orders'); ?> : <span id="number_sales"><?= $count_sale ?></span></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-lg-12 mb-4">
        <div class="card">
            <div class="card-body p-2">
                <div class="">
                    <button type="button" class="btn btn-success btn-lg default float-left text-center mr-1" style="width: 30%!important;" data-toggle="modal" data-target="#AddSale">
                        <h4><?= display('paid'); ?></h4>
                    </button>
                    <button type="button" class="btn btn-primary btn-lg default float-left text-center mr-1" style="width: 30%!important;" onclick="saleBtn(1,1)">
                        <h4><?= display('print'); ?></h4>
                    </button>
                    <button type="button" class="btn btn-danger btn-lg default float-left text-center" style="width: 30%!important;" onclick="cancelPOS()">
                        <h4><?= display('close'); ?></h4>
                    </button>

                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    //  **********************select categorie
    $(document).ready(function() {
        $('.ChequeNum').hide();
        $('#customerSelect').select2();

        $('#ItemsNum span, #ItemsNum2 span').load("<?php echo site_url('pos/totiems') ?>");
        $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);
        $(".categories").on("click", function() {
            var filter = $(this).attr('id');
            $(this).parent().children().removeClass('selectedGat');
            $(this).addClass('selectedGat');
            $('#productList').load("<?php echo site_url('pos/load_product/') ?>/" + filter);

        });
        $(".addPct").on("click", function() {
            var filterprd = $(this).attr('id');
            $(this).parent().children().removeClass('selectedProd');
            $(this).addClass('selectedProd');
        });

        $(".selectype1").on("click", function() {
            var filterprd = $(this).attr('id');
            $(this).parent().children().removeClass('selectedbtm');
            $(this).addClass('selectedbtm');
            $.ajax({
                url: "<?php echo site_url('pos/add_typeone') ?>/",
                type: "POST",
                data: {
                    selectype1: filterprd
                },
                success: function(data) {},
                error: function(jqXHR, textStatus, errorThrown) {
                    alert("error");
                }
            });

        });
        $(".selectype2").on("click", function() {
            var filterprd = $(this).attr('id');
            $(this).parent().children().removeClass('selectedbtm2');
            $(this).addClass('selectedbtm2');
            $.ajax({
                url: "<?php echo site_url('pos/add_typetow') ?>/",
                type: "POST",
                data: {
                    selectype2: filterprd
                },
                success: function(data) {},
                error: function(jqXHR, textStatus, errorThrown) {
                    alert("error");
                }
            });

        });
        $('#servicemodal').on('show.bs.modal', function(e) {
            var posall_id = $(e.relatedTarget).data('id');
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url(); ?>/pos/servicemodal/',
                data: 'posall_id=' + posall_id,
                success: function(data) {
                    $('.fetchservice').html(data);
                    $('#service_posale').load("<?php echo site_url('pos/load_service_posale') ?>/" + posall_id);
                }
            });
        });
        $("#paymentMethod").change(function() {

            var p_met = $(this).find('option:selected').val();

            if (p_met === '0') {
                $('.Paid').show();
                $('.ChequeNum').hide();
            } else if (p_met === '2') {
                $('.Paid').hide();
                $('.ChequeNum').show();
                $('.ReturnChange').hide();
            }

        });
        // ********************************* change calculations
        $('#Paid').on('keyup', function() {
            var change = -(parseFloat($('#total').text()) - parseFloat($(this).val()));
            if (change < 0) {
                $('#ReturnChange span').text(change.toFixed(<?= settings()->decimals; ?>));
                $('#ReturnChange span').addClass("text-danger");
                $('#ReturnChange span').removeClass("text-info");
            } else {
                $('#ReturnChange span').text(change.toFixed(<?= settings()->decimals; ?>));
                $('#ReturnChange span').removeClass("text-danger");
                $('#ReturnChange span').addClass("text-info");
            }
        });
        $("#customerSelect").change(function() {

            var id = $(this).find('option:selected').val();
            if (id === '0') {
                $('.Remise').val('<?= settings()->discount; ?>');
                $('#phoneClient').val('');
            } else {
                $.ajax({
                    url: "<?php echo site_url('pos/GetDiscount') ?>/" + id,
                    type: "POST",
                    success: function(data) {
                        var values = data.split('~');
                        if (values[2] > 0) {
                            $('#customerIDA').val(values[2]);
                        }
                        $('#customerName span').text(values[1]);
                        $('.Remise').val(values[0]);
                        $('#phoneClient').val(values[3]);
                        $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        alert("error");
                    }
                });
            }
        });

    });

    function add_prodpos(id) {
        var name1 = $('#idname-' + id).val();
        var priceprod = $('#price-' + id).val();
        $('.addPctlead-' + id).parent().children().removeClass('selectedProd');
        $('.addPctlead-' + id).addClass('selectedProd');

        $.ajax({
            url: "<?php echo site_url('pos/add_prodcart') ?>/",
            type: "POST",
            data: {
                idproduct: id,
                name: name1,
                priceprod: priceprod
            },
            success: function(data) {},
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });

    }

    function add_posale() {
        var color = $('#color').val();
        var qtecart = $('#qtecartnpt').val();
        $.ajax({
            url: "<?php echo site_url('pos/add_posale') ?>/",
            type: "POST",
            data: {
                color: color,
                qtecart: qtecart
            },
            success: function(data) {
                $('#cartview').load("<?php echo site_url('pos/load_posales') ?>");
                $('#ItemsNum span, #ItemsNum2 span').load("<?php echo site_url('pos/totiems') ?>");

                $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);
                $('.selectype1').removeClass('selectedbtm');
                $('.selectype2').removeClass('selectedbtm2');
                $('.addPct').removeClass('selectedProd');
                $('#qtecartnpt').val('1');
                $('.sound2').get(0).play();

            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });
    }

    function add_service(id, posale_id) {
        var service_id = id;
        var posale_id = posale_id;
        $.ajax({
            url: "<?php echo site_url('pos/add_service') ?>/",
            type: "POST",
            data: {
                service_id: service_id,
                posale_id: posale_id
            },
            success: function(data) {
                $('#cartview').load("<?php echo site_url('pos/load_posales') ?>");
                $('#service_posale').load("<?php echo site_url('pos/load_service_posale') ?>/" + posale_id);
                $('#ItemsNum span, #ItemsNum2 span').load("<?php echo site_url('pos/totiems') ?>");
                $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);

            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });
    }

    function delete_posale(id) {
        $.ajax({
            url: "<?php echo site_url('pos/delete') ?>/" + id,
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                $('#cartview').load("<?php echo site_url('pos/load_posales') ?>");
                $('#service_posale').load("<?php echo site_url('pos/load_service_posale') ?>/" + data.parent_id);
                $('#ItemsNum span, #ItemsNum2 span').load("<?php echo site_url('pos/totiems') ?>");
                $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);
                $('.sound1').get(0).play();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });
    }

    function edit_posale(id, type) {
        $.ajax({
            url: "<?php echo site_url('pos/edit_posale') ?>/" + id + "/" + type,
            type: "POST",
            dataType: "JSON",
            success: function(data) {
                $('#cartview').load("<?php echo site_url('pos/load_posales') ?>");

                $('#ItemsNum span, #ItemsNum2 span').load("<?php echo site_url('pos/totiems') ?>");
                $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });

    }

    function cancelPOS() {

        $('#customerSelect').val('0');
        $.ajax({
            url: "<?php echo site_url('pos/ResetPos') ?>/",
            type: "POST",
            success: function(data) {
                $('#cartview').load("<?php echo site_url('pos/load_posales') ?>");
                $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);
                $('#ItemsNum span, #ItemsNum2 span').text("0");
                $('.Remise').val('<?= settings()->discount; ?>');
                $('.TAX').val('<?= settings()->tax; ?>');
                $('.sound1').get(0).play();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });
    }

    // Add a customer
    function saveclt() {
        var num = $('#num').val();
        var phone = $('#phone').val();
        var lastname = $('#lastname').val();
        var firstname = $('#firstname').val();
        var adress = $('#adress').val();
        var discountclt = $('#discountclt').val();
        if (lastname != '' && firstname != '') {
            $.ajax({
                url: "<?php echo base_url('clients/add') ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    num: num,
                    phone: phone,
                    lastname: lastname,
                    firstname: firstname,
                    adress: adress,
                    discount: discountclt
                },
                success: function(data) {
                    $('#saveclt_result').html(data.msg);
                    $('#customerSelect').load("<?php echo site_url('clients/load_clients/') ?>" + data.insertid);
                    $('#clientModal').modal('toggle');
                    if (data.add == 'add') {
                        $('#num').val('');
                        $('#phone').val('');
                        $('#lastname').val('');
                        $('#firstname').val('');
                        $('#adress').val('');

                    } else {
                        $('.sounderr').get(0).play();
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert("error");
                }
            });
        } else {
            $('.error_validateclt').html(' * <?= display('this_fieldis_required') ?>');
        }
    }

    function PrintTicket() {
        $('.modal-body').removeAttr('id');
        window.print();
        $('.modal-body').attr('id', 'modal-body');
        window.close();
    }
    // function to calculate the total number
    function total_change() {
        var tot;
        if (($('.TAX').val().indexOf('%') == -1) && ($('.Remise').val().indexOf('%') == -1)) {
            tot = parseFloat($('#Subtot').text().replace(/ /g, '')) + parseFloat($('.TAX').val() ? $('.TAX').val() : 0);
            $('#taxValue').text('<?= settings()->currency; ?>');
            $('#RemiseValue').text('<?= settings()->currency; ?>');
            tot = tot - parseFloat($('.Remise').val() ? $('.Remise').val() : 0);
            $('#total').text(tot.toFixed(<?= settings()->decimals; ?>));
            $('#Paid').val(tot.toFixed(<?= settings()->decimals; ?>));
            $('#TotalModal').text('total ' + tot.toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
        } else if (($('.TAX').val().indexOf('%') != -1) && ($('.Remise').val().indexOf('%') == -1)) {
            tot = parseFloat($('#Subtot').text()) + percentage($('#Subtot').text(), $('.TAX').val());
            $('#taxValue').text(percentage($('#Subtot').text(), $('.TAX').val()).toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
            $('#RemiseValue').text('<?= settings()->currency; ?>');
            tot = tot - parseFloat($('.Remise').val() ? $('.Remise').val() : 0);
            $('#total').text(tot.toFixed(<?= settings()->decimals; ?>));
            $('#Paid').val(tot.toFixed(<?= settings()->decimals; ?>));
            $('#TotalModal').text('total ' + tot.toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
        } else if (($('.TAX').val().indexOf('%') != -1) && ($('.Remise').val().indexOf('%') != -1)) {
            tot = parseFloat($('#Subtot').text()) + percentage($('#Subtot').text(), $('.TAX').val());
            $('#taxValue').text(percentage($('#Subtot').text(), $('.TAX').val()).toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
            tot = tot - percentage($('#Subtot').text(), $('.Remise').val());
            $('#RemiseValue').text(percentage($('#Subtot').text(), $('.Remise').val()).toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
            $('#total').text(tot.toFixed(<?= settings()->decimals; ?>));
            $('#Paid').val(tot.toFixed(<?= settings()->decimals; ?>));
            $('#TotalModal').text('Total' + tot.toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
        } else if (($('.TAX').val().indexOf('%') == -1) && ($('.Remise').val().indexOf('%') != -1)) {
            tot = parseFloat($('#Subtot').text()) + parseFloat($('.TAX').val() ? $('.TAX').val() : 0);
            tot = tot - percentage($('#Subtot').text(), $('.Remise').val());
            $('#taxValue').text('<?= settings()->currency; ?>');
            $('#RemiseValue').text(percentage($('#Subtot').text(), $('.Remise').val()).toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
            $('#total').text(tot.toFixed(<?= settings()->decimals; ?>));
            $('#Paid').val(tot.toFixed(<?= settings()->decimals; ?>));
            $('#TotalModal').text('Total ' + tot.toFixed(<?= settings()->decimals; ?>) + ' <?= settings()->currency; ?>');
        }
    }

    function saleBtn(type, printcheck=null) {
        var clientID = $('#customerSelect').find('option:selected').val();
        var clientName = $('#customerName span').text();
        var phoneClient = $('#phoneClient').val();
        var delivery_date = $('#delivery_date').val();
        var pickup_date = $('#pickup_date').val();
        var Tax = $('.TAX').val();
        var Discount = $('.Remise').val();
        var Subtotal = $('#Subtot').text();
        var Total = $('#total').text();
        var createdBy = '<?= $this->user_name; ?>';
        var totalItems = $('#ItemsNum span').text();
        if(pickup_date !== '' && delivery_date !== ''){
        if(printcheck == 1){
            var Paid = 0;
        }else{
            var Paid = $('#Paid').val();
        }
        
        var paidMethod = $('#paymentMethod').find('option:selected').val();
        var Status = 0;
        switch (paidMethod) {
            case '1':
                paidMethod += '~' + $('#CreditCardNum').val() + '~' + $('#CreditCardHold').val();
                break;
            case '2':
                paidMethod += '~' + $('#ChequeNum').val()
                break;
            case '0':
                var change = parseFloat(Total) - parseFloat(Paid);
                if (change == parseFloat(Total)) Status = 1;
                else if (change > 0) Status = 2;
                else if (change <= 0) Status = 0;
        }
        var taxamount = $('.TAX').val().indexOf('%') != -1 ? parseFloat($('#taxValue').text()) : $('.TAX').val();
        var discountamount = $('.Remise').val().indexOf('%') != -1 ? parseFloat($('#RemiseValue').text()) : $('.Remise').val();

        $.ajax({
            url: "<?php echo site_url('pos/AddNewSale') ?>/" + type,
            type: "POST",
            data: {
                client_id: clientID,
                phoneclient:phoneClient,
                 delivery_date:delivery_date,
                  pickup_date:pickup_date,
                clientname: clientName,
                discountamount: discountamount,
                taxamount: taxamount,
                tax: Tax,
                discount: Discount,
                subtotal: Subtotal,
                total: Total,
                created_by: createdBy,
                totalitems: totalItems,
                paid: Paid,
                status: Status,
                paidmethod: paidMethod
            },
            success: function(data) {
                $('#printSection').html(data);
                $('#cartview').load("<?php echo site_url('pos/load_posales') ?>");
                $('#ItemsNum span, #ItemsNum2 span').load("<?php echo site_url('pos/totiems') ?>");
                $('#number_sales').load("<?php echo site_url('pos/number_sales') ?>");
                $('#total_sales').load("<?php echo site_url('pos/total_sales') ?>");
                $('#Subtot').load("<?php echo site_url('pos/subtot') ?>", null, total_change);
                $('#AddSale').modal('hide');
                $('#ticket').modal('show');
                $('.check-print').val(printcheck);
                $('#ReturnChange span').text('0');
                $('#Paid').val('0');
                $('.sound1').get(0).play();
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });
            
        }else{
            alert('Pickup date and delivery are required');
        }
    }

    function CloseRegister() {
        $.ajax({
            url: "<?php echo site_url('pos/CloseRegister') ?>/",
            type: "POST",
            success: function(data) {
                $('#closeregsection').html(data);
                $('#CloseRegister').modal('show');
                setTimeout(function() {
                    $('#countedcash').focus()
                }, 1000);
                $('#countedcash').on('keyup', function() {
                    var change = -(parseFloat($('#expectedcash').text()) - parseFloat($(this).val()));
                    var difftot = change + parseFloat($('#diffcheque').text());
                    var total = parseFloat($('#countedcheque').val()) + parseFloat($('#countedcash').val());
                    $('#countedtotal').text(total.toFixed(<?= settings()->decimals; ?>));
                    $('#difftotal').text(difftot.toFixed(<?= settings()->decimals; ?>))
                    if (change < 0) {
                        $('#diffcash').text(change.toFixed(<?= settings()->decimals; ?>));
                        $('#diffcash').addClass("red");
                        $('#diffcash').removeClass("light-blue");
                    } else {
                        $('#diffcash').text(change.toFixed(<?= settings()->decimals; ?>));
                        $('#diffcash').removeClass("red");
                        $('#diffcash').addClass("light-blue");
                    }
                });

                $('#countedcc').on('keyup', function() {
                    var change = -(parseFloat($('#expectedcc').text()) - parseFloat($(this).val()));
                    var difftot = parseFloat($('#diffcash').text()) + parseFloat($('#diffcheque').text());
                    var total = parseFloat($('#countedcheque').val()) + parseFloat($('#countedcash').val());
                    $('#countedtotal').text(total.toFixed(<?= settings()->decimals; ?>));
                    $('#difftotal').text(difftot.toFixed(<?= settings()->decimals; ?>))
                    if (change < 0) {
                        $('#diffcc').text(change.toFixed(<?= settings()->decimals; ?>));
                        $('#diffcc').addClass("red");
                        $('#diffcc').removeClass("light-blue");
                    } else {
                        $('#diffcc').text(change.toFixed(<?= settings()->decimals; ?>));
                        $('#diffcc').removeClass("red");
                        $('#diffcc').addClass("light-blue");
                    }
                });

                $('#countedcheque').on('keyup', function() {
                    var change = -(parseFloat($('#expectedcheque').text()) - parseFloat($(this).val()));
                    var difftot = change + parseFloat($('#diffcash').text());
                    var total = parseFloat($('#countedcheque').val()) + parseFloat($('#countedcash').val());
                    $('#countedtotal').text(total.toFixed(<?= settings()->decimals; ?>));
                    $('#difftotal').text(difftot.toFixed(<?= settings()->decimals; ?>))
                    if (change < 0) {
                        $('#diffcheque').text(change.toFixed(<?= settings()->decimals; ?>));
                        $('#diffcheque').addClass("red");
                        $('#diffcheque').removeClass("light-blue");
                    } else {
                        $('#diffcheque').text(change.toFixed(<?= settings()->decimals; ?>));
                        $('#diffcheque').removeClass("red");
                        $('#diffcheque').addClass("light-blue");
                    }
                });
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });
    }

    function SubmitRegister() {
        var expectedcash = $('#expectedcash').text();
        var countedcash = $('#countedcash').val();
        var expectedcheque = $('#expectedcheque').text();
        var countedcheque = $('#countedcheque').val();
        var RegisterNote = $('#RegisterNote').val();

        $.ajax({
            url: "<?php echo site_url('pos/SubmitRegister') ?>/",
            type: "POST",
            data: {
                expectedcash: expectedcash,
                countedcash: countedcash,
                expectedcheque: expectedcheque,
                countedcheque: countedcheque,
                RegisterNote: RegisterNote
            },
            success: function(data) {
                window.location.href = "<?php echo site_url() ?>";
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });

    }

    function SaleSearch() {
        var saleid = $('#salesearch').val();
        if(saleid.length==10){
            $.ajax({
            url: "<?php echo site_url('pos/salesearchbyphone') ?>/",
            type: "POST",
            data: {
                saleid: saleid
            },
            success: function(data) {
                // console.log(data);
                if (data != '') {
                    $('#sectionviewsale').html(data);
                    $('#SaleView').modal('show');
                    $('#errorsale_searsh').html('');
                    // $('#msgdelivery').html('');
                } else {
                    $('#errorsale_searsh').html('<?= display('invoice_does_not_exist') ?>');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
            });
        }else{
            $.ajax({
            url: "<?php echo site_url('pos/salesearch') ?>/",
            type: "POST",
            data: {
                saleid: saleid
            },
            success: function(data) {
                if (data != '') {
                    $('#sectionviewsale').html(data);
                    $('#SaleView').modal('show');
                    $('#errorsale_searsh').html('');
                    $('#msgdelivery').html('');
                } else {
                    $('#errorsale_searsh').html('<?= display('invoice_does_not_exist') ?>');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
            });
        }
        
    }

    function viewReciet(id){
        $('#salesearch').val(id);
        $('#sectionviewsale').html(' ');
        $('#SaleView').modal('hide');
        SaleSearch();
    }

    function productSearch() {
        var productid = $('#productsearch').val();
        $.ajax({
            url: "<?php echo site_url('pos/productSearch') ?>/",
            type: "POST",
            data: {
                productid: productid
            },
            success: function(data) {
                if (data != '') {
                    $('#productList').remove();
                    $(data).insertAfter('.productsearch');
                    $('#errorproduct_search').html('');
                } else {
                    $('#errorproduct_search').html('<?= display('product_does_not_exist') ?>');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("error");
            }
        });
    }

    function delivery(id, type) {
        var notesale = $('#notesale').val();
        var total = $('#deliverytotal').val();
        var paid = $('#deliverypaid').val();
        var rest = $('#rest').val();
        $.ajax({
            url: "<?php echo site_url('pos/delivery') ?>/" + id + "/" + type,
            type: "POST",
            dataType: "JSON",
            data: {
                notesale: notesale,
                rest: rest,
                total: total,
                paid: paid
            },
            success: function(data) {
                $('#msgdelivery').html(data.msg);
                $('.paid_after').html(data.paid_after);
                $('.rest_after').html(data.rest_after);
                $('#notesale').val(data.notesale_after);
                $('#deliverybtm').hide();
                $('#deliverypay').hide();
                $('.lbl-rest').hide();
                $('#rest').hide();
                var  html = "Hey "+data.clientname+", Your order has been picked up from "+data.store_name+" Please let us know if you have any feedback.  "+data.store_name;
                    var action_url = "https://wa.me/91"+data.phone+"?text="+html;
                    window.open(action_url, '_blank');

            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("errorddd");
            }
        });

    }
    function sendsms(id) {
        $.ajax({
            url: "<?php echo site_url('pos/smsreadycollection') ?>/" + id,
            type: "POST",
            dataType: "JSON",
            data: {
                idsale: id,
            },
            success: function(data) {
                $('#smslabel').html(data.msgtesra);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert("errorddd");
            }
        });

    }
</script>

<!-- Modal -->
<!-- ModaL client -->
<div class="modal fade modal-left" id="clientModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> <?= display('add_new_customer') ?> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="idclt" id="idclt" value="">

                <div class="form-group position-relative error-l-50">
                    <label> <?= display('num') ?></label>
                    <?PHP
                    $invID = str_pad($this->client->last_id() + 1, 3, '0', STR_PAD_LEFT);
                    $numclt = 'CL' . $invID;
                    ?>
                    <input type="text" class="form-control" placeholder="" name="num" id="num" autocomplete="off" value="<?= $numclt ?>" readonly="readonly">
                </div>
                <div class="form-group">
                    <label> <?= display('first_name') ?> <span class="text-danger error_lastname">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="lastname" id="lastname" autocomplete="off">
                </div>
                <div class="form-group">
                    <label> <?= display('last_name') ?> <span class="text-danger error_firstname">*</span></label>
                    <input type="text" class="form-control" placeholder="" name="firstname" id="firstname" autocomplete="off">
                </div>
                <div class="form-group">
                    <label> <?= display('phone') ?></label>
                    <input type="text" class="form-control" placeholder="" name="phone" id="phone" autocomplete="off">
                </div>
                <div class="form-group">
                    <label> <?= display('adress') ?></label>
                    <input type="text" class="form-control" placeholder="" name="adress" id="adress">
                </div>
                <div class="form-group">
                    <label> <?= display('discounts') . ' (' . settings()->currency ?>)</label>
                    <input type="text" class="form-control" placeholder="" name="discountclt" id="discountclt">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?= display('close') ?></button>
                <button type="button" class="btn btn-primary" id="saveclt" onclick="saveclt()"><?= display('save') ?></button>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="AddSale" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?= display('add_an_invoice') ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form>
                <div class="modal-body">
                    <div class="form-group">
                        <h2 id="customerName"><?= display('client') ?> <span> <?= display('default_client') ?></span></h2>
                    </div>
                    <div class="form-group">
                        <h3 id="ItemsNum2"><span></span> <?= display('number_of_services') ?> </h3>
                    </div>
                    <div class="form-group">
                        <h2 id="TotalModal"></h2>
                    </div>
                    <div class="form-group">
                        <label for="paymentMethod"> <?= display('payementtype') ?></label>
                        <select class="js-select-options form-control" id="paymentMethod">
                            <option value="0"><?= display('cash') ?></option>
                            <option value="2"><?= display('cheque') ?></option>
                            <option value="3">Card</option>
                            <option value="4">UPI</option>
                            
                        </select>
                    </div>
                    <div class="form-group Paid">
                        <label for="Paid"><?= display('paid') ?></label>
                        <input type="text" value="0" name="paid" class="form-control " id="Paid" placeholder="<?= display('paid') ?>">
                    </div>

                    <div class="clearfix"></div>

                    <div class="form-group ChequeNum">
                        <label for="ChequeNum"><?= display('check_number') ?></label>
                        <input type="text" name="chequenum" class="form-control" id="ChequeNum" placeholder="<?= display('check_number') ?>">
                    </div>
                    <div class="form-group ReturnChange">
                        <h3 id="ReturnChange"><?= display('rest') ?> <span>0</span> <?= settings()->currency; ?></h3>
                    </div>

                    <div class="clearfix"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?= display('close') ?></button>
                    <button type="button" class="btn btn-primary" onclick="saleBtn(1,0)"><?= display('paid') ?></button>
                </div>
                <?php echo form_close(); ?>
        </div>
    </div>
</div>
<!-- CloseRegister -->
<div class="modal fade" id="CloseRegister" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel"><?= display('close_the_sale') ?></h4>
            </div>
            <div class="modal-body">
                <div id="closeregsection">
                    <!-- close register detail goes here -->
                </div>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="SubmitRegister()" class="btn btn-sm btn-danger ml-3 d-none d-md-inline-block w-25 text-center"><?= display('close_the_sale') ?></a>
            </div>
        </div>
    </div>
</div>
<div class="modal" id="servicemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalRight" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width: 600px;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"> <?= display('additional_services') ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="needs-validation">
                <div class="modal-body">
                    <div class="fetchservice">

                    </div>
                    <hr>
                    <div id="service_posale" class="form-group">

                    </div>



                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-primary" data-dismiss="modal"><?= display('hide') ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal ticket -->
<div class="modal fade" id="ticket" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog" role="document" id="ticketModal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ticket"><?= display('receipt') ?> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

            </div>
            <div class="modal-body" id="modal-body" style="margin-top: 0px;padding: 5px; padding-bottom: 0px">
                <div id="printSection" style="padding-bottom:0px; padding-top: 0px; margin-top: 0px; margin-bottom: 0px">
                    <!-- Ticket goes here -->
                    <center>
                        <h1 style="color:#34495E"><?= display('empty') ?></h1>
                    </center>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" class="check-print"/>
                <button type="button" class="btn btn-sm btn-danger hiddenpr" data-dismiss="modal"><?= display('close') ?></button>
                <button type="button" class="btn btn-sm btn-success hiddenpr" onclick="PrintTicket()"><?= display('print') ?></button>
               
            </div>
        </div>
    </div>
</div>
<div class="modal fade modal-left" id="SaleView" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog" role="document" id="" style="max-width:500px;">
        <div class="modal-content">
            <div class="modal-header">

                <div class="modal-body" id="" style="margin-top: 0px;padding: 5px; padding-bottom: 0px">
                    <span id="msgdelivery"></span>
                    <span id="smslabel"></span>
                    <div id="sectionviewsale" style="padding-bottom:0px; padding-top: 0px; margin-top: 0px; margin-bottom: 0px">
                        <!-- Ticket goes here -->
                        <center>
                            <h1 style="color:#34495E"><?= display('empty') ?></h1>
                        </center>
                        <input type="text" readonly>
                    </div>
                </div>

            </div>
        </div>
    </div>



    <script src="<?= base_url(); ?>assets/js/bootstrap-input-spinner.js"></script>
    <script>
        $("input[type='number']").inputSpinner();
    </script>
    
    
